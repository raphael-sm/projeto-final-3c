<?php

namespace App\Http\Requests;

use App\Support\TaxId;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;

/**
 * PATCH /api/auth/me — profile update. Every field is optional; the user's
 * tax document can be replaced but never removed (an account always carries
 * exactly one of cpf/cnpj after registration).
 */
class UpdateProfileRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['sometimes', 'required', 'string', 'max:255'],
            'email' => ['sometimes', 'required', 'string', 'email', 'max:255', Rule::unique('users', 'email')->ignore($this->user()?->id)],
            'password' => ['sometimes', 'required', Password::min(8)],
            'document' => [
                'sometimes',
                'required',
                'string',
                function (string $attribute, mixed $value, \Closure $fail): void {
                    $digits = preg_replace('/\D/', '', (string) $value) ?? '';

                    if (!in_array(strlen($digits), [11, 14], true)) {
                        $fail('O documento deve ser um CPF (11 dígitos) ou CNPJ (14 dígitos).');

                        return;
                    }

                    if (!TaxId::isValid($digits)) {
                        $fail('O documento informado é inválido.');
                    }
                },
            ],
            'birthday' => ['sometimes', 'required', 'date', 'before:-18 years'],
        ];
    }

    /** Normalize the document to digits only after validation passes. */
    protected function passedValidation(): void
    {
        if ($this->has('document')) {
            $this->merge([
                'document' => preg_replace('/\D/', '', $this->input('document')) ?? '',
            ]);
        }
    }
}
