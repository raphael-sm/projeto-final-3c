<?php

namespace App\Http\Requests;

use App\Support\TaxId;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;

class RegisterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', Password::min(8)],
            // Exactly one document is provided and it must carry valid check digits.
            'document' => [
                'required',
                'string',
                function (string $attribute, mixed $value, \Closure $fail): void {
                    $digits = preg_replace('/\D/', '', (string) $value) ?? '';

                    if (! in_array(strlen($digits), [11, 14], true)) {
                        $fail('O documento deve ser um CPF (11 dígitos) ou CNPJ (14 dígitos).');

                        return;
                    }

                    if (! TaxId::isValid($digits)) {
                        $fail('O documento informado é inválido.');
                    }
                },
            ],
            'birthday' => ['required', 'date', 'before:-18 years'],
        ];
    }

    /** Normalize the document to digits only after validation passes. */
    protected function passedValidation(): void
    {
        $digits = preg_replace('/\D/', '', $this->input('document')) ?? '';

        $this->merge([
            'document' => $digits,
        ]);
    }
}
