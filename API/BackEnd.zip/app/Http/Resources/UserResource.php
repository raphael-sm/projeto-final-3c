<?php

namespace App\Http\Resources;

use App\Support\TaxId;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            // Masked on purpose: the raw value never leaves the API (LGPD).
            'document' => $this->cpf !== null
                ? TaxId::mask($this->cpf)
                : ($this->cnpj !== null ? TaxId::mask($this->cnpj) : null),
            'document_type' => $this->cnpj !== null ? 'cnpj' : ($this->cpf !== null ? 'cpf' : null),
            'birthday' => $this->birthday,
            'role' => $this->role?->name,
            'created_at' => $this->created_at,
        ];
    }
}
