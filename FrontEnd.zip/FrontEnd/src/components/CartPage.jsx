import { useEffect, useMemo, useState } from "react";
import CartItem from "./CartItem";
import CartSummary from "./CartSummary";
import { cartTotals } from "../data/cart";
import { fetchAddresses, syncCart, checkout } from "../data/api";
import { mockAddresses, mockCartConfig } from "../data/mock";

/** Carrinho: `cart` vem de useCart(); `session` é o usuário logado (ou null). */
export default function CartPage({ cart, session, onRequireLogin, config = mockCartConfig }) {
  const { items, setQuantity, remove, clear } = cart;
  const [addresses, setAddresses] = useState([]);
  const [addressId, setAddressId] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [order, setOrder] = useState(null); // preenchido após finalizar

  // TODO: trocar por cotação real de frete (por endereço/itens) quando a API tiver.
  const totals = useMemo(() => cartTotals(items, config.shipping), [items, config.shipping]);

  useEffect(() => { document.title = "Meu Carrinho | Logoipsum Eletrônicos"; }, []);

  useEffect(() => {
    if (!session) { setAddresses([]); setAddressId(""); return; }
    let off = false;
    fetchAddresses()
      .catch((err) => { console.error("Falha ao buscar endereços, usando exemplo:", err); return mockAddresses; })
      .then((list) => {
        if (off) return;
        setAddresses(list);
        setAddressId((list.find((a) => a.isDefault) ?? list[0])?.id ?? "");
      });
    return () => { off = true; };
  }, [session]);

  const finish = async () => {
    if (!session) return onRequireLogin?.();
    if (!addressId) return setError("Selecione um endereço de entrega.");
    setBusy(true); setError("");
    try {
      await syncCart(items);                        // envia os itens locais para o carrinho da API
      const result = await checkout({ addressId }); // POST /api/checkout
      clear();
      setOrder(result ?? {});
    } catch (err) {
      setError(err.message || "Não foi possível finalizar a compra.");
    } finally {
      setBusy(false);
    }
  };

  if (order) {
    return (
      <main className="cart cart--message">
        <h1 className="cart__title">Compra realizada!</h1>
        <p>{order.id ? `Pedido #${order.id} registrado com sucesso.` : "Seu pedido foi registrado com sucesso."}</p>
        <a className="summary__btn cart__link-btn" href="/loja">Continuar comprando</a>
      </main>
    );
  }

  if (!items.length) {
    return (
      <main className="cart cart--message">
        <h1 className="cart__title">Meu Carrinho</h1>
        <p>Seu carrinho está vazio.</p>
        <a className="summary__btn cart__link-btn" href="/loja">Ver produtos</a>
      </main>
    );
  }

  return (
    <main className="cart">
      <section className="cart__main" aria-labelledby="cart-title">
        <h1 id="cart-title" className="cart__title">Meu Carrinho</h1>
        <div className="cart__box">
          <div className="cart__row cart__head" aria-hidden="true">
            <span>Produto</span><span>Qtd.</span><span>Preço à vista</span>
          </div>
          <ul className="cart__list">
            {items.map((item) => <CartItem key={item.id} item={item} onQuantity={setQuantity} onRemove={remove} />)}
          </ul>
        </div>
      </section>
      <CartSummary
        {...totals} installments={config.installments}
        addresses={addresses} addressId={addressId} onAddress={setAddressId} loggedIn={!!session}
        onCheckout={finish} busy={busy} error={error} />
    </main>
  );
}
