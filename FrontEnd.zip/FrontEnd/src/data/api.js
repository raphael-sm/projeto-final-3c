// Integração com a API Laravel. Ajuste VITE_API_URL no .env (veja .env.example).
export const API = import.meta.env.VITE_API_URL ?? "http://localhost:8000/api";

// Aceita tanto [..] quanto { data: [..] } (API Resources do Laravel).
const list = (json) => json?.data ?? json ?? [];
const headers = {
    'Accept': 'application/json'
}

export const mainImage = (images = []) =>
  [...images].sort((a, b) => a.position - b.position)[0]?.url ?? "";

/** Converte o produto da API (GET /api/products) no formato do ProductCard/Store. */
export const fromApi = (p, categories = []) => {
  const price = Number(p.price);
  return {
    id: p.id,
    name: p.name,
    price,
    fullPrice: Number(p.full_price ?? price), // a API ainda não envia preço "à vista" separado
    rating: Number(p.rating ?? 0),
    reviews: p.reviews_count ?? 0,
    manufacturer: p.manufacturer ?? p.specs?.fabricante ?? "",
    category: categories.find((c) => c.id === p.category_id)?.slug ?? "",
    image: mainImage(p.images),
    images: p.images ?? [], // galeria completa, para a página de detalhe
    href: `/produto/${p.id}`,
  };
};

export async function fetchStoreData() {
  const [cats, prods] = await Promise.all([
    fetch(`${API}/categories`, {
        headers: headers
    }).then((r) => r.json()),
    fetch(`${API}/products`, {
        headers: headers
    }).then((r) => r.json()),
  ]);
  const categories = list(cats);
  return { categories, products: list(prods).map((p) => fromApi(p, categories)) };
}

// Rótulos das especificações (chaves de `specs` da API). Chaves desconhecidas são "humanizadas".
const SPEC_LABELS = {
  microcontrolador: "Microcontrolador",
  tensao: "Tensão de Operação",
  tensao_entrada: "Tensão de Entrada",
  pinos_digitais: "Portas Digitais",
  pinos_analogicos: "Portas Analógicas",
  corrente_io: "Corrente Pinos I/O",
  corrente_3v3: "Corrente Pinos 3,3V",
  memoria_flash: "Memória Flash",
  sram: "SRAM",
  eeprom: "EEPROM",
  clock: "Velocidade do Clock",
};
export const specLabel = (key) =>
  SPEC_LABELS[key] ?? key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, " ");

/** Converte o produto completo da API (GET /api/products/:id) para a página de produto. */
export const fromApiDetail = (p) => {
  const price = Number(p.price);
  return {
    id: p.id,
    sku: p.sku,
    name: p.name,
    about: p.about ?? "",
    specs: p.specs ?? {},
    price,
    fullPrice: Number(p.full_price ?? price), // a API ainda não envia preço "à vista" separado
    stock: p.stock ?? 0,
    rating: Number(p.rating ?? 0),
    reviews: p.reviews_count ?? 0,
    categoryId: p.category_id,
    images: [...(p.images ?? [])].sort((a, b) => a.position - b.position),
  };
};

export async function fetchProductData(id) {
  const res = await fetch(`${API}/products/${id}`);
  if (!res.ok) throw new Error(`Produto ${id}: HTTP ${res.status}`);
  const json = await res.json();
  return fromApiDetail(json.data ?? json);
}

// --------------------------------------------------------------------------
// Autenticação (Sanctum tokens)
// --------------------------------------------------------------------------
const TOKEN_KEY = "auth_token";

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t) => localStorage.setItem(TOKEN_KEY, t);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);

/** Headers padrão + Authorization quando há token salvo. */
export function authHeaders(extra = {}) {
  const token = getToken();
  return {
    Accept: "application/json",
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...extra,
  };
}

/** POST /api/auth/login — troca credenciais por { user, token }. */
export async function login({ username, password }) {
  if (!username.trim() || !password) throw new Error("Informe usuário e senha.");

  const res = await fetch(`${API}/auth/login`, {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ email: username.trim(), password }),
  });

  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(json?.message ?? "Não foi possível entrar. Verifique usuário e senha.");
  }

  setToken(json.token);
  return json.user; // { id, name, email, role }
}

/** POST /api/auth/register */
export async function register({ name, email, password }) {
  const res = await fetch(`${API}/auth/register`, {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, password }),
  });

  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(json?.message ?? Object.values(json?.errors ?? {})[0]?.[0] ?? "Falha ao criar conta.");
  }

  setToken(json.token);
  return json.user;
}

/** POST /api/auth/logout */
export async function logout() {
  try {
    await fetch(`${API}/auth/logout`, { method: "POST", headers: authHeaders() });
  } finally {
    clearToken();
  }
}

/** GET /api/auth/me — valida o token salvo; retorna o usuário ou null. */
export async function fetchMe() {
  if (!getToken()) return null;
  const res = await fetch(`${API}/auth/me`, { headers: authHeaders() });
  if (!res.ok) {
    clearToken();
    return null;
  }
  const json = await res.json();
  return json.data ?? json;
}

/** DELETE /api/cart — esvazia o carrinho do usuário autenticado. */
export async function clearCart() {
  const res = await fetch(`${API}/cart`, { method: "DELETE", headers: authHeaders() });
  if (!res.ok) throw new Error(`Falha ao esvaziar carrinho (HTTP ${res.status})`);
}

/** POST /api/checkout — finaliza a compra do carrinho autenticado. */
export async function checkout({ addressId, address } = {}) {
  const res = await fetch(`${API}/checkout`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({ ...(addressId ? { address_id: addressId } : {}), ...(address ? { address } : {}) }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json?.message ?? "Falha ao finalizar a compra.");
  return json.data ?? json;
}

// --------------------------------------------------------------------------
// Carrinho / endereços  (ENDPOINTS SUPOSTOS: ajuste para o que a API Laravel expõe)
// --------------------------------------------------------------------------
/** GET /api/addresses — endereços do usuário autenticado. */
export async function fetchAddresses() {
  const res = await fetch(`${API}/addresses`, { headers: authHeaders() });
  if (!res.ok) throw new Error(`Falha ao buscar endereços (HTTP ${res.status})`);
  return list(await res.json()).map((a) => ({
    id: String(a.id),
    label: a.label ?? a.name ?? "Endereço",
    text: a.formatted ?? [a.street, a.number, a.complement, a.city].filter(Boolean).join(", "),
    isDefault: !!(a.is_default ?? a.default),
  }));
}

/** PUT /api/cart — substitui o carrinho do servidor pelos itens locais antes do checkout. */
export async function syncCart(items) {
  const res = await fetch(`${API}/cart`, {
    method: "PUT",
    headers: authHeaders(),
    body: JSON.stringify({ items: items.map((i) => ({ product_id: i.id, quantity: i.quantity })) }),
  });
  if (!res.ok) {
    const json = await res.json().catch(() => ({}));
    throw new Error(json?.message ?? "Falha ao enviar o carrinho.");
  }
}
